<?php if (isset($component)) { $__componentOriginal1f9e5f64f242295036c059d9dc1c375c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c = $attributes; } ?>
<?php $component = App\View\Components\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
         <?php $__env->slot('title', null, []); ?> Home | Kevin.dev <?php $__env->endSlot(); ?>

        <div class="text-center">
            <h1 class="text-3xl font-bold">Welcome to My Portfolio</h1>
        </div>

    
  
    <div class="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
      <div class="relative isolate overflow-hidden rounded-3xl bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 shadow-2xl">
        <div class="px-6 py-16 sm:px-16 lg:flex lg:items-center lg:justify-between lg:px-24">
          <!-- Text Section -->
          <div class="text-center lg:text-left max-w-xl">
            <h1 class="text-4xl font-bold tracking-tight text-white sm:text-5xl">
              Hi, I'm Kevin 👋
            </h1>
            <p class="mt-4 text-lg text-gray-300">
              A passionate <span class="text-sky-400 font-semibold">Web & Mobile Developer</span> building elegant, responsive, and high-performance apps using modern technologies like Laravel, Flutter, and Tailwind CSS.
            </p>
  
            <div class="mt-8 flex flex-col sm:flex-row sm:justify-center lg:justify-start gap-4">
              <a href="/projects" class="inline-block rounded-md bg-white px-6 py-3 text-sm font-semibold text-gray-900 shadow hover:bg-gray-200 transition">
                View My Work
              </a>
              <a href="/contact" class="inline-block rounded-md border border-white px-6 py-3 text-sm font-semibold text-white hover:bg-white/10 transition">
                Let's Connect
              </a>
            </div>
          </div>
  
          <!-- Image Section -->
          <div class="relative mt-10 lg:mt-0 lg:ml-12 w-full max-w-xl">
            <img class="rounded-lg shadow-lg ring-1 ring-white/10 w-full object-cover" src="https://tailwindcss.com/plus-assets/img/component-images/dark-project-app-screenshot.png" alt="App Preview">
          </div>
        </div>
      </div>
    </div>
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $attributes = $__attributesOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__attributesOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c)): ?>
<?php $component = $__componentOriginal1f9e5f64f242295036c059d9dc1c375c; ?>
<?php unset($__componentOriginal1f9e5f64f242295036c059d9dc1c375c); ?>
<?php endif; ?>
  <?php /**PATH C:\laragon\www\portfolio-web\resources\views/home.blade.php ENDPATH**/ ?>